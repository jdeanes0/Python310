WTF, like nothing happened today with code.... This makes me sad. (9/6/23)
SOMETHING MIGHT HAPPEN TODAY (9/8/23)
This will get out of hand quickly. It is time to folderize.

Okay. This will be a very deep and complicated inheritance tree.

